#include <stdio.h>

void main()
{
    puts("ftz{**fake_flag**}\n");
}