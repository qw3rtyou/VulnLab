#!/bin/bash
cd /home/pickle
/usr/bin/python3 myPickle.py
exit
