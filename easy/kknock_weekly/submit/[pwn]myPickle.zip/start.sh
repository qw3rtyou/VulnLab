#!/bin/bash
/etc/init.d/xinetd restart
/bin/bash
sleep infinity
