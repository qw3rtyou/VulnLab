def flag():
	print("KCTF{zzlolololol}")
	exit(0)

if(__name__ == "__main__"):
	pass